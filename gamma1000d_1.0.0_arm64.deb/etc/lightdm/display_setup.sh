#!/bin/bash

# Disable screen blanking and power saving
xset s off
xset -dpms
xset s noblank

# Rotate the screen
xhost +local:root

xrandr -o left
exit 0
